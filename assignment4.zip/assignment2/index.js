$(document).ready(function(){
  var cnt = $('#learn').hide();
    $('#cont').click(function(){
      $('#learn').show();
    });
});
