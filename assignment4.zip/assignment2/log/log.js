$(document).ready(function(){
  $('#log').click(function(){
    var email = $("#email").val();
    var pas = $("#pas").val();
    var pass = $("#pass").val();
    if (email == ""){
      $("#empty").text('Please enter your email').css('color', 'red');
    }
    else if (pas == "") {
      alert("Enter your password");
    }
    else if (pass == "") {
      alert("Repeat your password");
    }
    else if (pas!=pass) {
      alert("Your password doesn't match");
    }
    else{
      alert("Your data is saved");
    }
  });
});
